package com.dev.fi.footballapps.data

/**
 ****************************************
created by -manca-
.::manca.fi@gmail.com ::.
 ****************************************
 */

data class EventResponse(
        val event: List<Event>)
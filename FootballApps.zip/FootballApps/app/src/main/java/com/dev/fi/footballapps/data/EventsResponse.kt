package com.dev.fi.footballapps.data

/**
 ****************************************
created by -manca-
.::manca.fi@gmail.com ::.
 ****************************************
 */

data class EventsResponse(
        val events: List<Event>)
package com.dev.fi.footballapps.data

/**
 ****************************************
created by -manca-
.::manca.fi@gmail.com ::.
 ****************************************
 */

data class PlayerResponse(
        val player: List<Player>)
package com.dev.fi.footballapps.ui.detailMatch

import com.dev.fi.footballapps.data.Event

/**
 ****************************************
created by -manca-
.::manca.fi@gmail.com ::.
 ****************************************
 */

interface DetailMatchV {
    fun showDetail(data: Event)
}
package com.dev.fi.footballapps.utils

/**
 ****************************************
created by -manca-
.::manca.fi@gmail.com ::.
 ****************************************
 */
interface SpinnerListener1{
    fun onItemSelected(item: String)
}

interface SpinnerListener2{
    fun onItemSelected(item: String)
}